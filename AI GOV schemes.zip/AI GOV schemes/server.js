const express = require('express');
const cors = require('cors'); // Import CORS middleware

const app = express();

// Use CORS to handle cross-origin requests
app.use(cors());

// Default Route
app.get('/', (req, res) => {
    res.send('Welcome to the AI-Gov Schemes Platform!');
});

// Dummy data for schemes
const schemes = [
    { id: 1, name: "Pradhan Mantri Jan Dhan Yojana", ageLimit: 60, incomeLimit: 250000, description: "Financial inclusion for rural citizens.", applyLink: "https://pmjdy.gov.in/" },
    { id: 2, name: "Ayushman Bharat", ageLimit: 40, incomeLimit: 300000, description: "Health insurance for underprivileged families.", applyLink: "https://pmjay.gov.in/" },
    { id: 3, name: "Digital India", ageLimit: 50, incomeLimit: 400000, description: "Promoting digital infrastructure and literacy.", applyLink: "https://digitalindia.gov.in/" }
];

// Route for fetching all schemes
app.get('/schemes', (req, res) => {
    res.json(schemes);
});

// Route for checking eligibility
app.get('/check-eligibility', (req, res) => {
    const { age, income } = req.query;

    if (!age || !income) {
        return res.status(400).send("Please provide both age and income as query parameters.");
    }

    const eligibleSchemes = schemes.filter(
        scheme => parseInt(age) <= scheme.ageLimit && parseInt(income) <= scheme.incomeLimit
    );

    if (eligibleSchemes.length > 0) {
        res.json({
            message: "You are eligible for the following schemes:",
            schemes: eligibleSchemes
        });
    } else {
        res.json({ message: "You are not eligible for any schemes.", schemes: [] });
    }
});

// Start the server
const PORT = 4000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
