// Handle DigiLocker form submission
document.getElementById('digilocker-form').addEventListener('submit', async function (event) {
    event.preventDefault(); // Prevent the form from refreshing the page

    // Get the DigiLocker ID
    const digilockerId = document.getElementById('digilocker-id').value;

    if (digilockerId) {
        console.log(`DigiLocker ID submitted: ${digilockerId}`);

        // Simulate API call to fetch eligible schemes
        try {
            const age = prompt("Enter your age:"); // Ask for user age
            const income = prompt("Enter your annual income:"); // Ask for user income

            if (!age || !income) {
                alert("Please provide both age and income.");
                return;
            }

            const response = await fetch(
                `http://localhost:4000/check-eligibility?age=${age}&income=${income}`
            );

            if (!response.ok) {
                throw new Error('Failed to fetch eligible schemes');
            }

            const data = await response.json();

            // Show the schemes section
            document.getElementById('digilocker-section').style.display = 'none';
            document.getElementById('scheme-list-section').style.display = 'block';

            // Display schemes
            displaySchemes(data.schemes);
        } catch (error) {
            console.error(error);
            alert('An error occurred while fetching schemes. Please try again.');
        }
    } else {
        alert('Please enter a valid DigiLocker ID.');
    }
});

// Function to display schemes
function displaySchemes(schemes) {
    const schemeList = document.getElementById('scheme-list');
    schemeList.innerHTML = ''; // Clear existing schemes

    if (schemes.length === 0) {
        schemeList.innerHTML = '<p>No schemes found for your eligibility.</p>';
        return;
    }

    schemes.forEach((scheme) => {
        const schemeCard = document.createElement('div');
        schemeCard.className = 'scheme-card';

        schemeCard.innerHTML = `
            <h3>${scheme.name}</h3>
            <p>${scheme.description}</p>
            <a href="${scheme.applyLink}" target="_blank">Apply Now</a>
        `;

        schemeList.appendChild(schemeCard);
    });
}
